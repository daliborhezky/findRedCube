using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    [SerializeField] GameObject menuObj;
    [SerializeField] CameraMovement cameraMovement;
    [SerializeField] PlayerMovement playerMovement;
    bool active = false;
    // Start is called before the first frame update
    void Start()
    {
        menuObj.SetActive(false);
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            menuObj.SetActive(!menuObj.activeInHierarchy);
            if (active)
            {
                active = false;
            } else
            {
                active = true;
            }
            Cursor.visible = active;
            print(active);

            cameraMovement.SetCanMove(!active);
            playerMovement.SetCanMove(!active);

            if (active)
            {
                Cursor.lockState = CursorLockMode.None;
            } else
            {
                Cursor.lockState = CursorLockMode.Locked;
            }
            
            
        }
    }

    public void MainMenu()
    {
        SceneManager.LoadScene(0);
    }

    public void Reset()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
