using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System;

public class GrabObjects : MonoBehaviour
{
    [SerializeField] Transform cam;
    [SerializeField] Transform addedObj;
    [SerializeField] Transform grabPoint;
    [SerializeField] float scrollStrength = 0.1f;
    Vector3 grabPointOrigin;

    string condition;

    [Header("Stats")]
    [SerializeField] float grabedObjectMoveSpeed = 5;

    Rigidbody rb;
    float oldObjDrag;
    float oldObjAngularDrag;
    RigidbodyInterpolation oldObjInterpolation;
    CollisionDetectionMode oldObjCollisionDetectionMode;

    [Header("New Object Pick Up")]
    [SerializeField] float newDrag = 5;
    [SerializeField] float newAngularDrag = 5;
    [SerializeField] RigidbodyInterpolation newInterpolation = RigidbodyInterpolation.Interpolate;
    [SerializeField] CollisionDetectionMode newCollisionDetectionMode = CollisionDetectionMode.Continuous;
    [SerializeField] float onDropVelocityDecrease = 3;

    [Header("Mouse Image")]
    [SerializeField] Transform mouseImage;
    [SerializeField] float mouseImageYOffset = 0.1f;

    [Header("E")]
    [SerializeField] Transform EText;

    void Start()
    {
        mouseImage.GetComponent<Image>().enabled = false;
        EText.GetComponent<TMP_Text>().enabled = false;
        grabPointOrigin = grabPoint.localPosition;
        //print("grabPointZOrigin: 2: " + grabPointZOrigin);
    }
    // Update is called once per frame
    void Update()
    {
        if (Physics.Raycast(cam.position, cam.forward, out RaycastHit hit, 2.5f)) // Check for picking up object
        {
            if (hit.transform.GetComponent<Rigidbody>() != null)
            {
                if (addedObj == null)
                {
                    mouseImage.GetComponent<Image>().enabled = true;
                    mouseImage.LookAt(Camera.main.transform);

                    Vector3 targetPos = hit.transform.position;
                    targetPos.y += hit.transform.localScale.y/2 + mouseImageYOffset;
                    mouseImage.position = targetPos;
                } else
                {
                    mouseImage.GetComponent<Image>().enabled = false;
                }
                

                if (Input.GetKey(KeyCode.Mouse0) && addedObj == null)
                {
                    PickUpObject(hit.transform);
                }
            } else
            {
                mouseImage.GetComponent<Image>().enabled = false;
            }
        } else
        {
            mouseImage.GetComponent<Image>().enabled = false;
        }

        if (Input.GetKeyUp(KeyCode.Mouse0)) // Drop Object
        {
            DropObject(addedObj);
        }

        MoveObject(addedObj); // Move Object

        if (condition == "Win")
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                GoToNextLevel();
            }
        }

        
    }

    void MoveObject(Transform grabedObject)
    {
        // Možná i počítat s rb.Mass
        if (grabedObject == null) return;

        Vector3 dir = (grabPoint.position - grabedObject.position).normalized;
        //Rigidbody rb = grabedObject.GetComponent<Rigidbody>();

        float distance = Vector3.Distance(grabPoint.position, grabedObject.position);

        Vector3 velocityDir = dir * Time.deltaTime * grabedObjectMoveSpeed * 10 * distance / rb.mass;
        rb.velocity = velocityDir;

        ChangeGrabPointZ();
        
    }

    void PickUpObject(Transform grabedObject)
    {
        addedObj = grabedObject;
        rb = addedObj.GetComponent<Rigidbody>();
        
        oldObjDrag = rb.drag;
        oldObjAngularDrag = rb.angularDrag;
        oldObjInterpolation = rb.interpolation;
        oldObjCollisionDetectionMode = rb.collisionDetectionMode;

        rb.drag = newDrag;
        rb.angularDrag = newAngularDrag;
        rb.interpolation = newInterpolation;
        rb.collisionDetectionMode = newCollisionDetectionMode;

        CheckPickedUpObject(addedObj);
    }

    void DropObject(Transform grabedObject)
    {
        if (grabedObject == null) return;

        rb.drag = oldObjDrag;
        rb.angularDrag = oldObjAngularDrag;
        rb.interpolation = oldObjInterpolation;
        rb.collisionDetectionMode = oldObjCollisionDetectionMode;

        rb.velocity /= onDropVelocityDecrease;

        grabPoint.localPosition = grabPointOrigin;

        addedObj = null;
        CheckPickedUpObject(null);
    }

    void CheckPickedUpObject(Transform grabedObject)
    {
        if (grabedObject == null)
        {
            condition = "";
            EText.GetComponent<TMP_Text>().enabled = false;
            return;   
        }

        if (grabedObject.CompareTag("Red Cube"))
        {
            EText.GetComponent<TMP_Text>().enabled = true;
            condition = "Win";
            // set condition to win if player presses E
        }
    }

    void GoToNextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
    }

    void ChangeGrabPointZ()
    {
        Vector3 grabPointPos = grabPoint.localPosition;

        grabPointPos.z += Input.mouseScrollDelta.y * scrollStrength;
        grabPointPos.z = Math.Clamp(grabPointPos.z, 1.5f, 3f);

        grabPoint.localPosition = grabPointPos;
    }
}
