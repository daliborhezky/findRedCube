using System;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] float movementSpeed = 5;
    [SerializeField] Transform orientation;
    Rigidbody rb;
    float moveX;
    float moveY;
    bool canMove = true;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.freezeRotation = true;
    }

    // Update is called once per frame
    void Update()
    {
        ControllInput();
    }

    void FixedUpdate()
    {
        if (canMove)
        {
            MovePlayer();
        }
        
    }

    void ControllInput()
    {
        moveX = Input.GetAxisRaw("Horizontal");
        moveY = Input.GetAxisRaw("Vertical");
    }

    

    void MovePlayer()
    {
        Vector3 moveDir = orientation.forward * moveY + orientation.right * moveX;

        //rb.velocity = moveDir * movementSpeed;
        rb.AddForce(moveDir.normalized * movementSpeed * Time.deltaTime * 100f, ForceMode.Force);
    }

    public void SetCanMove(bool setbool)
    {
        canMove = setbool;
    }
}
