using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraPosition : MonoBehaviour
{
    [SerializeField] Transform playerCameraPosition;
    [SerializeField] float moveToBodySpeed = 50f;

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.Lerp(transform.position, playerCameraPosition.position, Time.deltaTime*moveToBodySpeed);
    }
}
