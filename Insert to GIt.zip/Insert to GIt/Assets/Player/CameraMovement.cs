using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class CameraMovement : MonoBehaviour
{
    [SerializeField] float mouseSensitivity = 5;
    [SerializeField] Transform orientation;
    float camYRot;
    float camXRot;
    bool canMove = true;
    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        transform.rotation = Quaternion.Euler(0,0,0);
        camYRot = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (canMove)
        {
            RotateCam();
        }
        
    }

    void RotateCam()
    {
        float moveCamX = Input.GetAxis("Mouse X") * mouseSensitivity;
        //transform.Rotate(0, moveCamX, 0);
        float camXRotOld = camXRot;
        float camYRotOld = camYRot;

        camXRot += moveCamX;

        float moveCamY = Input.GetAxis("Mouse Y") * mouseSensitivity;
        
        camYRot -= moveCamY;
        camYRot = Math.Clamp(camYRot, -85f, 85f);
        
        /*transform.rotation = Quaternion.Euler(camYRot, camXRot, 0);
        orientation.rotation = Quaternion.Euler(0, camXRot, 0);*/
        transform.rotation = Quaternion.Lerp(Quaternion.Euler(camYRotOld, camXRotOld, 0), Quaternion.Euler(camYRot, camXRot, 0), Time.deltaTime);
        orientation.rotation = Quaternion.Lerp(Quaternion.Euler(0, camXRotOld, 0), Quaternion.Euler(0, camXRot, 0), Time.deltaTime);
        
    }

    public void SetCanMove(bool setbool)
    {
        canMove = setbool;
    }
}
