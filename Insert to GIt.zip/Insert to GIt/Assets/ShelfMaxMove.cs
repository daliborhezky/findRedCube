using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShelfMaxMove : MonoBehaviour
{
    /*Vector3 startPos;
    Vector3 maxPos;
    Rigidbody rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();

        startPos = transform.position;
        maxPos = startPos+transform.forward;
        print(startPos + " " + maxPos);
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 currentPos = transform.position;
        currentPos.x = Math.Clamp(currentPos.x, startPos.x, maxPos.x);
        currentPos.y = Math.Clamp(currentPos.y, startPos.y, maxPos.y);
        currentPos.z = Math.Clamp(currentPos.z, startPos.z, maxPos.z);

        print(transform.position.magnitude - currentPos.magnitude);
        transform.position = currentPos;
    }*/

    public Rigidbody rb;
    public float maxDistance = 1f;

    private Vector3 startPosition;
    private Vector3 slideDirection;

    void Start()
    {
        startPosition = rb.position;

        // The door's local Y axis, converted to world direction
        slideDirection = transform.up;
    }

     void FixedUpdate()
    {
        Vector3 displacement = rb.position - startPosition;

        // How far the door has moved along its sliding axis
        float distance = Vector3.Dot(displacement, slideDirection);

        if (distance > maxDistance)
        {
            Vector3 correction =
                slideDirection * (distance - maxDistance);

            rb.position -= correction;
        }
    }
}
