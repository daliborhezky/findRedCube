using System.Collections;
using System.Collections.Generic;
using UnityEngine;

enum targetTypes {
    Nothing,
    SlideDoor,
    SlotMachine
}

public class Lever : MonoBehaviour
{
    [Header("Init")]
    [SerializeField] Transform leverBase;
    [SerializeField] Transform targetObj;
    [SerializeField] targetTypes targetObjType;
    bool activated = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //print(leverBase.localRotation.eulerAngles);
        if (leverBase.localRotation.eulerAngles.x > 40 && leverBase.localRotation.eulerAngles.x < 60)
        {
            if (!activated)
            {
                activated = true;
                Activate(true);
            }
        } else
        {
            if (activated)
            {
                activated = false;
                Activate(false);
            }
        }
    }

    void Activate(bool active)
    {
        switch (targetObjType)
        {
            case targetTypes.Nothing:
                return;
            case targetTypes.SlideDoor:
                targetObj.GetComponent<SlideDoor>().Activate(active);
                break;
            case targetTypes.SlotMachine:
                targetObj.GetComponent<SlotMachine>().Activate(active);
                break;
            default:
                return;
        }
        /*if (active)
        {
            print("active");
        }*/
    }
}
