using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Timeline;

public class SlotMachine : MonoBehaviour
{
    int num1;
    int num2;
    int num3;
    [SerializeField] TMP_Text text1;
    [SerializeField] TMP_Text text2;
    [SerializeField] TMP_Text text3;

    bool stopChanging = true;
    bool canPlay = true;
    [SerializeField] int round;

    [SerializeField] SlideDoor slideDoor;

    public void Activate(bool active)
    {
        if (!active)
        {
            return;
        }

        //StartCoroutine(NumberChanger());
        if (!stopChanging || !canPlay)
        {
            return;
        }

        ActivateNumberChanger();
    }

    IEnumerator NumberChanger()
    {
        while (!stopChanging)
        {
            num1 = Random.Range(1, 10);
            num2 = Random.Range(1, 10);
            num3 = Random.Range(1, 10);
            
            text1.text = num1.ToString();
            text2.text = num2.ToString();
            text3.text = num3.ToString();
            yield return new WaitForSeconds(0.1f);
        }
        
    }

    void ActivateNumberChanger()
    {
        StartCoroutine(StopNumberChanging());
        StartCoroutine(NumberChanger());
    }

    IEnumerator StopNumberChanging()
    {
        round++;
        stopChanging = false;
        yield return new WaitForSeconds(2f);
        stopChanging = true;
        if (num1 == 7 && num2 == num1 && num3 == num1)
        {
            Win();
        }
        if (round == 15)
        {
            Win();
        }
    }

    void Win()
    {
        text1.text = "7";
        text2.text = "7";
        text3.text = "7";
        canPlay = false;
        slideDoor.Activate(true);
    }
}
