using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlideDoor : MonoBehaviour
{
    //[SerializeField] Transform door;
    [SerializeField] float moveSpeed = 2;
    [SerializeField] Vector3 endPosDir = Vector3.zero;
    Vector3 startPos;
    Vector3 endPos;
    
    Vector3 movePos;
    // Start is called before the first frame update
    void Start()
    {
        startPos = transform.position;
        endPos = startPos;
        endPos += endPosDir;
        //endPos.y += 0.9f;

        movePos = startPos;
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, movePos, Time.deltaTime * moveSpeed);
    }

    public void Activate(bool active)
    {
        if (active)
        {
            movePos = endPos;
        } else
        {
            movePos = startPos;
        }
    }
}
